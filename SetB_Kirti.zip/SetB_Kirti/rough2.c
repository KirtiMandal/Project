#include<stdio.h>
#include<string.h>

void main(){

char name[50];
int i=0;
scanf("%s",name);
printf("%s",name);
}
